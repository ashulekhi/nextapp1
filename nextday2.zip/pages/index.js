import {Navbar} from "../components/Navbar"
import NewHome from "./Home"
export default  function Home(){
  return (
    <>
   
    <NewHome />
    
    </>
  )
}

