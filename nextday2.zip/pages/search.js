export default function Search(){
    return (
        <>
        Search Page 
        </>
    )
}