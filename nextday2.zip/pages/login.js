import styles from "./login.module.css"

export default function Login(){

    // api 
    return (
        <>
        <div className={styles.loginform}>
          Login Page 
        </div>
       
        </>
    )
}