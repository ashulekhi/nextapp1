export default function Signup(){
    return (
        <>
        Signup Page 
        </>
    )
}

export async function getServerSideProps(){
    console.log("Page generated at each request not only one time ")
    return {
        props:{
            
        }
    }
}