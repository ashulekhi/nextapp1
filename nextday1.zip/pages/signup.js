export default function(){
    return (
        <>
        Signup Page 
        </>
    )
}