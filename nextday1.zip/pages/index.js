import {Navbar} from "../components/Navbar"

export default  function Home(){
  return (
    <>
   
    <h1>Hello Welcome to Our Next JS First App</h1>
    </>
  )
}

