export default function(){
    return (
        <>
        Search Page 
        </>
    )
}