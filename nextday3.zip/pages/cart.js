export default function Cart(props){
    return (
        <>
            {props.name}  Cart page 
        </>
    )}


    // export async function getStaticProps(){
    //     console.log(">>>>>>>>>>>>>>>>>>> running at server" , process.env.BASE_URL)
    //     return {
    //         props:{
    //             name:"Ashu Lekhi"
    //         }
    //     }
    // }