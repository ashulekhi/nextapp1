import styles from "./login.module.css"
import useRouter from "next/router"

export default function Login(){

    // api 
    let login = ()=>{
      useRouter.push("/")
    }
    var user = {}
    var login = ()=>{
        axios({
            method:"post",
            url:process.env.BASE_URL+"/login",
            data:user
        }).then((response)=>{
            console.log("response from login api" , response)
        },(error)=>{
            console.log("error from login api", error)
        })
    }
    return (
        <>
                <input onChange={(e)=>{user.name=e.target.value}} className="form-control" placeholder="Email"> </input>
                <input onChange={(e)=>{user.name=e.target.value}} className="form-control" type="password" placeholder="Password"> </input>
                <button className="btn btn-primary" onClick={login}>Login</button>
        </>
    )
}